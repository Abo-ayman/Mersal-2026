import 'dart:convert';

import 'package:android_id/android_id.dart';
import 'package:crypto/crypto.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

/// Signs the user in with an account derived from the device ID.
/// First launch creates the account; reinstalling the app on the same device
/// (same signing key) signs in to the same account again.
class DeviceIdentity {
  static SupabaseClient get _db => Supabase.instance.client;

  static Future<void> ensureSignedIn() async {
    if (_db.auth.currentSession != null) return;

    final id = await const AndroidId().getId();
    if (id == null || id.isEmpty) {
      throw Exception('تعذر قراءة معرف الجهاز');
    }
    // Supabase rejects fake domains (no MX records), so a real domain is used.
    // No email is ever sent (Confirm email is off). Recognised by the DB trigger.
    final email = 'mrsl.${id.toLowerCase()}@gmail.com';
    final password =
        sha256.convert(utf8.encode('$id|${AppConfig.deviceSalt}')).toString();

    try {
      await _db.auth.signInWithPassword(email: email, password: password);
    } on AuthException {
      // No account yet for this device: create it.
      final res = await _db.auth.signUp(email: email, password: password);
      if (res.session == null) {
        throw Exception(
            'تعذر إنشاء الحساب. تأكد من تعطيل Confirm email في إعدادات Supabase.');
      }
    }
  }
}
