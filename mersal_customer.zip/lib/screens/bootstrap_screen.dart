import 'package:flutter/material.dart';

import '../core/device_identity.dart';
import '../core/logo.dart';
import '../core/push.dart';
import '../data/order_repository.dart';
import 'home_screen.dart';
import 'name_screen.dart';

class BootstrapScreen extends StatefulWidget {
  const BootstrapScreen({super.key});

  @override
  State<BootstrapScreen> createState() => _BootstrapScreenState();
}

class _BootstrapScreenState extends State<BootstrapScreen> {
  String? _error;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    setState(() => _error = null);
    try {
      await DeviceIdentity.ensureSignedIn();
      Push.register();
      final profile = await OrderRepository().getProfile();
      if (!mounted) return;
      final hasName = (profile['display_name'] as String?)?.isNotEmpty ?? false;
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => hasName ? const HomeScreen() : const NameScreen(),
      ));
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const MersalLogo(markSize: 120),
              const SizedBox(height: 24),
              if (_error == null)
                const CircularProgressIndicator()
              else ...[
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: _start, child: const Text('إعادة المحاولة')),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
