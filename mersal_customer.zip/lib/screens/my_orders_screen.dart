import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';

const _statusAr = {
  'awaiting_review': 'بانتظار مراجعة السائق',
  'awaiting_customer_approval': 'بانتظار موافقتك على السعر',
  'pending_driver': 'بانتظار قبول السائق',
  'processing': 'جارٍ معالجة طلبك',
  'ready': 'جاهز للتوصيل',
  'on_the_way': 'في الطريق',
  'delivered': 'تم التسليم',
  'rejected': 'مرفوض',
  'cancelled': 'ملغى',
};

Map<String, dynamic>? _details(Map<String, dynamic> o) {
  final d = o['custom_order_details'];
  if (d is List) return d.isEmpty ? null : Map<String, dynamic>.from(d.first);
  if (d is Map) return Map<String, dynamic>.from(d);
  return null;
}

class MyOrdersScreen extends StatefulWidget {
  const MyOrdersScreen({super.key});

  @override
  State<MyOrdersScreen> createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> {
  final _repo = OrderRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.myOrders();

  void _reload() => setState(() => _future = _repo.myOrders());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('طلباتي')),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return ListView(children: [
                const SizedBox(height: 120),
                const Center(child: Text('تعذر تحميل الطلبات')),
                Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
              ]);
            }
            final orders = snap.data!;
            if (orders.isEmpty) {
              return ListView(children: const [
                SizedBox(height: 120),
                Center(child: Text('لا توجد طلبات بعد')),
              ]);
            }
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final o = orders[i];
                final d = _details(o);
                final status = o['status'] as String;
                return Card(
                  child: ListTile(
                    title: Text(d?['item_name'] ?? 'طلب #${o['order_number']}',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('#${o['order_number']} · ${_statusAr[status] ?? status}'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () async {
                      await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => OrderDetailScreen(orderId: o['id'])));
                      _reload();
                    },
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class OrderDetailScreen extends StatefulWidget {
  final String orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final _repo = OrderRepository();
  late Future<Map<String, dynamic>> _future = _repo.getOrder(widget.orderId);
  bool _busy = false;

  void _reload() => setState(() => _future = _repo.getOrder(widget.orderId));

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _approve(Map<String, dynamic> o) async {
    setState(() => _busy = true);
    try {
      final res = await _repo.approve(o['id'], o['total'] as num);
      if (res['ok'] == true) {
        _msg('تمت الموافقة. بدأنا معالجة طلبك.');
      } else {
        _msg('تغيّر السعر الإجمالي إلى ${res['new_total']} ل.ت. راجعه ثم وافق مجدداً.');
      }
    } catch (e) {
      _msg(friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
      _reload();
    }
  }

  Future<void> _cancel(Map<String, dynamic> o) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('إلغاء الطلب'),
        content: const Text('هل تريد إلغاء هذا الطلب؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم، إلغاء')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _busy = true);
    try {
      await _repo.cancel(o['id'], reason: 'ألغاه الزبون');
    } catch (e) {
      _msg(friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
      _reload();
    }
  }

  Widget _row(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Text(k),
          const Spacer(),
          Text(v, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الطلب')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return const Center(child: Text('تعذر تحميل الطلب'));
          final o = snap.data!;
          final d = _details(o);
          final status = o['status'] as String;
          final quoted = d?['quoted_price'] != null;
          final canDecide = status == 'awaiting_customer_approval';
          final canCancel = const ['awaiting_review', 'awaiting_customer_approval', 'pending_driver']
              .contains(status);
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                    color: Brand.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(14)),
                child: Text('${_statusAr[status] ?? status}',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ),
              const SizedBox(height: 16),
              Text(d?['item_name'] ?? '',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              if ((d?['description'] ?? '').toString().isNotEmpty) Text(d!['description']),
              const SizedBox(height: 8),
              _row('رقم الطلب', '#${o['order_number']}'),
              _row('الكمية', '${d?['quantity'] ?? 1}'),
              if (d?['image_url'] != null) ...[
                const SizedBox(height: 8),
                ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.network(d!['image_url'], height: 160, fit: BoxFit.cover)),
              ],
              const Divider(height: 32),
              if (quoted) ...[
                const Text('الفاتورة',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                _row('قيمة المنتجات', '${o['items_subtotal']} ل.ت'),
                _row('التوصيل الأساسي', '${o['delivery_base']} ل.ت'),
                if ((o['distance_fee'] as num) > 0) ...[
                  _row('رسوم المسافة', '${o['distance_fee']} ل.ت'),
                  const Text('أضيفت رسوم مسافة بسبب تجاوز النطاق الأساسي',
                      style: TextStyle(color: Colors.black54, fontSize: 12)),
                ],
                if ((o['time_fee'] as num) > 0) ...[
                  _row(o['time_fee_kind'] == 'night' ? 'رسوم خدمة ليلية VIP' : 'رسوم خدمة مسائية',
                      '${o['time_fee']} ل.ت'),
                ],
                _row('إجمالي التوصيل', '${o['delivery_total']} ل.ت'),
                const Divider(),
                _row('الإجمالي النهائي', '${o['total']} ل.ت', bold: true),
                _row('طريقة الدفع', 'نقداً عند الاستلام'),
                if ((d?['quote_note'] ?? '').toString().isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text('ملاحظة السائق: ${d!['quote_note']}'),
                  ),
              ] else
                const Text('سنراجع طلبك ونرسل لك السعر قريباً.'),
              const SizedBox(height: 20),
              if (canDecide)
                FilledButton(
                    onPressed: _busy ? null : () => _approve(o),
                    child: Text('موافق، نفّذ الطلب (${o['total']} ل.ت)')),
              if (canCancel) ...[
                const SizedBox(height: 10),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(52)),
                    onPressed: _busy ? null : () => _cancel(o),
                    child: Text(canDecide ? 'رفض العرض وإلغاء الطلب' : 'إلغاء الطلب')),
              ],
              const SizedBox(height: 10),
              TextButton(onPressed: _reload, child: const Text('تحديث الحالة')),
            ],
          );
        },
      ),
    );
  }
}
