# تطبيق الزبون (نسخة تجريبية)

1. flutter create delivery_customer
2. انسخ مجلد lib وملف pubspec.yaml من هذا المشروع فوق الموجود.
3. flutter pub get && flutter run

رمز التحقق التجريبي: 1234
