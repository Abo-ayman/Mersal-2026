import '../models/models.dart';

// بيانات تجريبية، تُستبدل لاحقاً بالبيانات القادمة من الخادم
const stores = <Store>[
  Store(id: 1, name: 'سوبرماركت الأمل', category: 'بقالة', address: 'وسط جرابلس', isOpen: true),
  Store(id: 2, name: 'مخبز الشام', category: 'مخبوزات', address: 'شارع المشفى', isOpen: true),
  Store(id: 3, name: 'صيدلية النور', category: 'صيدلية', address: 'الحي الشرقي', isOpen: false),
];

const products = <Product>[
  Product(id: 1, storeId: 1, name: 'أرز 1 كغ', description: 'أرز مصري حبة طويلة', sellerPrice: 40),
  Product(id: 2, storeId: 1, name: 'زيت عباد الشمس 1 لتر', description: 'زيت نباتي', sellerPrice: 65),
  Product(id: 3, storeId: 1, name: 'سكر 1 كغ', description: 'سكر أبيض ناعم', sellerPrice: 30),
  Product(id: 4, storeId: 1, name: 'شاي 250 غ', description: 'شاي أسود', sellerPrice: 55, isAvailable: false),
  Product(id: 5, storeId: 2, name: 'خبز عربي (ربطة)', description: '10 أرغفة طازجة', sellerPrice: 15),
  Product(id: 6, storeId: 2, name: 'معجنات جبنة', description: 'حبة واحدة', sellerPrice: 12),
  Product(id: 7, storeId: 3, name: 'مسكّن للألم', description: 'علبة 20 حبة', sellerPrice: 25),
];
