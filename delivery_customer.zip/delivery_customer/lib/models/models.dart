import '../config.dart';

class Store {
  final int id;
  final String name;
  final String category;
  final String address;
  final bool isOpen;

  const Store({
    required this.id,
    required this.name,
    required this.category,
    required this.address,
    required this.isOpen,
  });
}

class Product {
  final int id;
  final int storeId;
  final String name;
  final String description;
  final double sellerPrice;
  final bool isAvailable;

  const Product({
    required this.id,
    required this.storeId,
    required this.name,
    required this.description,
    required this.sellerPrice,
    this.isAvailable = true,
  });

  /// السعر الذي يراه الزبون = سعر البائع + نسبة المنصة
  double get finalPrice =>
      (sellerPrice * (1 + commissionPercent / 100) * 100).round() / 100;
}

String formatPrice(double v) {
  final s = v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);
  return '$s $currency';
}
