// إعدادات مؤقتة، لاحقاً تأتي من الخادم (جدول settings)
const double commissionPercent = 10; // نسبة ربح المنصة %
const String currency = 'ل.ت'; // غيّر العملة حسب ما تعتمدون
