// بيانات المستخدم الحالي (مؤقتة، لاحقاً من الخادم)
class Session {
  static String name = '';
  static String phone = '';
}
