import 'package:flutter/foundation.dart';
import '../models/models.dart';

class CartLine {
  final Product product;
  int qty;
  CartLine(this.product, this.qty);
}

class CartModel extends ChangeNotifier {
  int? storeId;
  final Map<int, CartLine> _lines = {};

  int qtyOf(Product p) => _lines[p.id]?.qty ?? 0;
  int get count => _lines.values.fold(0, (s, l) => s + l.qty);
  double get total =>
      _lines.values.fold(0.0, (s, l) => s + l.product.finalPrice * l.qty);

  void add(Product p) {
    storeId = p.storeId;
    final line = _lines[p.id];
    if (line == null) {
      _lines[p.id] = CartLine(p, 1);
    } else {
      line.qty++;
    }
    notifyListeners();
  }

  void remove(Product p) {
    final line = _lines[p.id];
    if (line == null) return;
    line.qty--;
    if (line.qty <= 0) _lines.remove(p.id);
    if (_lines.isEmpty) storeId = null;
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    storeId = null;
    notifyListeners();
  }
}

final cart = CartModel();
