import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../state/cart.dart';
import '../widgets/cart_bar.dart';

class StoreScreen extends StatelessWidget {
  final Store store;
  const StoreScreen({super.key, required this.store});

  Future<void> _add(BuildContext context, Product p) async {
    if (cart.storeId != null && cart.storeId != p.storeId) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          content: const Text(
              'سلتك تحتوي منتجات من متجر آخر. تفريغها والبدء من جديد؟'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('نعم'),
            ),
          ],
        ),
      );
      if (ok != true) return;
      cart.clear();
    }
    cart.add(p);
  }

  @override
  Widget build(BuildContext context) {
    final items = products.where((p) => p.storeId == store.id).toList();
    return Scaffold(
      appBar: AppBar(title: Text(store.name)),
      bottomNavigationBar: const CartBar(),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const Divider(height: 24),
        itemBuilder: (context, i) {
          final p = items[i];
          return Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.image, color: Colors.grey),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.name,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(p.description,
                        style: TextStyle(color: Colors.grey.shade600)),
                    const SizedBox(height: 4),
                    Text(formatPrice(p.finalPrice),
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              if (!p.isAvailable)
                const Text('غير متوفر', style: TextStyle(color: Colors.red))
              else
                ListenableBuilder(
                  listenable: cart,
                  builder: (context, _) {
                    final q = cart.qtyOf(p);
                    if (q == 0) {
                      return IconButton.filled(
                        onPressed: () => _add(context, p),
                        icon: const Icon(Icons.add),
                      );
                    }
                    return Row(
                      children: [
                        IconButton.outlined(
                          onPressed: () => cart.remove(p),
                          icon: const Icon(Icons.remove),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: Text('$q',
                              style: const TextStyle(fontSize: 16)),
                        ),
                        IconButton.filled(
                          onPressed: () => cart.add(p),
                          icon: const Icon(Icons.add),
                        ),
                      ],
                    );
                  },
                ),
            ],
          );
        },
      ),
    );
  }
}
