import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../state/session.dart';
import '../widgets/cart_bar.dart';
import 'store_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('مرحباً ${Session.name}')),
      bottomNavigationBar: const CartBar(),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FilledButton.icon(
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(72),
              textStyle: const TextStyle(fontSize: 20),
            ),
            icon: const Icon(Icons.local_shipping, size: 28),
            label: const Text('اطلب أي شي'),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('شاشة الطلب الحر قادمة قريباً')),
              );
            },
          ),
          const SizedBox(height: 24),
          const Text(
            'المتاجر',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          for (final s in stores)
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.storefront)),
                title: Text(s.name),
                subtitle: Text('${s.category} • ${s.address}'),
                trailing: Text(
                  s.isOpen ? 'مفتوح' : 'مغلق',
                  style: TextStyle(color: s.isOpen ? Colors.green : Colors.red),
                ),
                onTap: s.isOpen
                    ? () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => StoreScreen(store: s)),
                        )
                    : null,
              ),
            ),
        ],
      ),
    );
  }
}
