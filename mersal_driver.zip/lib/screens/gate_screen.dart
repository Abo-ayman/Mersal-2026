import 'dart:async';

import 'package:flutter/material.dart';

import '../core/app_init.dart';
import '../core/logo.dart';
import '../core/push.dart';
import '../data/staff_repository.dart';
import 'login_screen.dart';
import 'orders_screen.dart';

class GateScreen extends StatefulWidget {
  const GateScreen({super.key});

  @override
  State<GateScreen> createState() => _GateScreenState();
}

class _GateScreenState extends State<GateScreen> {
  String? _error;
  String _step = 'جارٍ التشغيل…';

  @override
  void initState() {
    super.initState();
    _route();
  }

  void _go(Widget next) {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => next));
  }

  Future<void> _route() async {
    setState(() => _error = null);
    try {
      // Push (Firebase) must never block start-up: run it on the side.
      final pushReady = Push.init().timeout(
        const Duration(seconds: 20),
        onTimeout: () {},
      );

      _step = 'الاتصال بالخادم…';
      await AppInit.supabase();

      final repo = StaffRepository();
      if (!repo.signedIn) return _go(const LoginScreen());

      if (mounted) setState(() => _step = 'التحقق من الحساب…');
      final staff = await repo.isStaff().timeout(const Duration(seconds: 20));
      if (!staff) {
        await repo.signOut();
        return _go(const LoginScreen());
      }
      unawaited(pushReady.then((_) => Push.register()));
      _go(const OrdersScreen());
    } on TimeoutException {
      if (mounted) {
        setState(() => _error =
            'انتهت مهلة الاتصال أثناء: $_step\nتأكد من الإنترنت ثم أعد المحاولة.');
      }
    } catch (e) {
      if (mounted) setState(() => _error = '$_step\n$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const MersalLogo(markSize: 100),
              const SizedBox(height: 24),
              if (_error == null) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 12),
                Text(_step, style: const TextStyle(color: Colors.black54)),
              ] else ...[
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: _route, child: const Text('إعادة المحاولة')),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => _go(const LoginScreen()),
                  child: const Text('الانتقال لتسجيل الدخول'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
