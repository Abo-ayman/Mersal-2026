import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../core/logo.dart';
import '../core/push.dart';
import '../data/staff_repository.dart';
import 'orders_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  String? _error;

  Future<void> _login() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    final repo = StaffRepository();
    try {
      await repo.signIn(_email.text, _pass.text);
      if (!await repo.isStaff()) {
        await repo.signOut();
        setState(() => _error = 'هذا الحساب غير مخوّل بالدخول');
        return;
      }
      Push.register();
      if (!mounted) return;
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const OrdersScreen()));
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 40),
            const Center(child: MersalLogo(markSize: 96)),
            const SizedBox(height: 8),
            const Center(child: Text('تطبيق السائق والإدارة')),
            const SizedBox(height: 32),
            TextField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _pass,
              obscureText: true,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(labelText: 'كلمة المرور'),
              onSubmitted: (_) => _busy ? null : _login(),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _busy ? null : _login,
              child: _busy
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('تسجيل الدخول'),
            ),
            const SizedBox(height: 32),
            FutureBuilder<PackageInfo>(
              future: PackageInfo.fromPlatform(),
              builder: (_, snap) => Center(
                child: Text(
                  snap.hasData ? 'الإصدار ${snap.data!.version} (${snap.data!.buildNumber})' : '',
                  style: const TextStyle(fontSize: 12, color: Colors.black45),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
