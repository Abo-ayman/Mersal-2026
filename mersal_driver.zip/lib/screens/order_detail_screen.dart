import 'dart:async';

import 'package:flutter/material.dart';
import '../core/icon3d.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/location_tracker.dart';
import '../core/theme.dart';
import '../data/staff_repository.dart';
import 'rating_widgets.dart';
import 'chat_button.dart';
import 'company_fees_screen.dart';

class OrderDetailScreen extends StatefulWidget {
  final String orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final _repo = StaffRepository();
  Map<String, dynamic>? _order;
  Object? _loadError;
  Map<String, dynamic>? _trip; // history: trip record
  Map<String, dynamic>? _fee; // history: company fee
  bool _busy = false;
  num _maxDeliveryDistance = 100; // meters (server setting delivery_max_distance_m)
  Timer? _poll; // taxi: follows the customer's start / end of the trip
  bool _endShown = false;

  @override
  void initState() {
    super.initState();
    LocationTracker.instance.state.addListener(_onTracker);
    _load();
    _poll = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!_busy && _order?['type'] == 'taxi') _load();
    });
  }

  @override
  void dispose() {
    LocationTracker.instance.state.removeListener(_onTracker);
    _poll?.cancel();
    super.dispose();
  }

  void _onTracker() {
    if (mounted) setState(() {});
  }

  /// Keeps location sharing on only while the driver has orders on the way / arrived.
  Future<void> _syncTracker() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      final active = await _repo.orders(['processing', 'ready', 'on_the_way', 'arrived']);
      await LocationTracker.instance
          .syncOrders(active.where((o) => o['driver_id'] == uid).toList());
    } catch (_) {}
  }

  Future<void> _load() async {
    try {
      final o = await _repo.order(widget.orderId);
      _repo.markSeen(widget.orderId);
      if (o['status'] == 'delivered' || o['status'] == 'cancelled') {
        try {
          final t = await _repo.tripFor(widget.orderId);
          final f = await _repo.feeFor(widget.orderId);
          if (mounted) setState(() {
            _trip = t;
            _fee = f;
          });
        } catch (_) {}
      }
      final prev = _order?['status'];
      if (mounted) {
        setState(() {
          _order = o;
          _loadError = null;
        });
        // the customer ended (or cancelled) the taxi trip while this screen was open
        final now = o['status'];
        if (o['type'] == 'taxi' && prev != null && prev != now &&
            (now == 'delivered' || now == 'cancelled') && !_endShown) {
          _endShown = true;
          _poll?.cancel();
          _showTaxiEnded(o);
        }
        _syncTracker();
        _repo.pricingSettings().then((s) {
          final v = s['delivery_max_distance_m'];
          if (v is num && mounted) setState(() => _maxDeliveryDistance = v);
        }, onError: (_) {});
      }
    } catch (e) {
      // a failed refresh must not hide an order that is already on the screen
      if (mounted && _order == null) setState(() => _loadError = e);
    }
  }

  Future<void> _showTaxiEnded(Map<String, dynamic> o) async {
    final delivered = o['status'] == 'delivered';
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        title: Text(delivered ? 'انتهت الرحلة' : 'ألغى الزبون الرحلة'),
        content: Text(delivered
            ? 'أنهى الزبون الرحلة. المبلغ المطلوب من الزبون نقداً: '
                '${fmt((o['total'] as num?) ?? 0)} ${o['currency_symbol'] ?? ''}'
            : 'تم إلغاء طلب التاكسي #${o['order_number']} من قبل الزبون.'),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً')),
        ],
      ),
    );
    if (mounted) Navigator.of(context).pop(); // back to the list; the trip is now in «السجل»
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  /// Runs a server action and shows a friendly error. Returns true on success.
  Future<bool> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
      await _load();
      return true;
    } catch (e) {
      final m = friendlyError(e);
      if (m == 'unpaid_fees_limit') {
        await _showFeesBlock();
      } else {
        _msg(m);
      }
      // show the order's real state from the server again
      if (mounted) await _load();
      return false;
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _showFeesBlock() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('لا يمكن قبول الطلب'),
        content: const Text(
            'وصلت إلى الحد الأقصى من الطلبات غير المسددة. يجب سداد رسوم الشركة المستحقة قبل قبول أي طلب جديد.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const CompanyFeesScreen()));
            },
            child: const Text('عرض رسوم الشركة'),
          ),
        ],
      ),
    );
  }

  Future<String?> _askReason() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('السبب'),
        content: TextField(
            controller: c, decoration: const InputDecoration(hintText: 'اكتب السبب')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رجوع')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأكيد')),
        ],
      ),
    );
    if (ok != true) return null;
    return c.text.trim();
  }

  Future<void> _reject(String to) async {
    final reason = await _askReason();
    if (reason == null) return;
    await _run(() => _repo.changeStatus(widget.orderId, to,
        reason: reason.isEmpty ? null : reason));
  }

  /// Delivery: the driver enters the real price of the goods; the server saves
  /// the invoice, marks it paid in cash and closes the order.
  Future<void> _deliver(Map<String, dynamic> o) async {
    final delivery = (o['delivery_total'] as num?) ?? 0;
    final cur = (o['currency_symbol'] ?? 'ل.ت').toString();
    final c = TextEditingController(
        text: ((o['items_subtotal'] as num?) ?? 0) > 0 ? fmt(o['items_subtotal'] as num) : '');
    final price = await showDialog<num>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          final p = num.tryParse(c.text.trim());
          return AlertDialog(
            title: const Text('تأكيد التسليم'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('اكتب سعر المشتريات التي اشتريتها للزبون ($cur):'),
                const SizedBox(height: 8),
                TextField(
                  controller: c,
                  autofocus: true,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (_) => setS(() {}),
                  decoration: const InputDecoration(hintText: '0'),
                ),
                const SizedBox(height: 10),
                Text('أجرة التوصيل: ${fmt(delivery)} $cur'),
                if (p != null)
                  Text('المبلغ الذي يدفعه الزبون نقداً: ${fmt(p + delivery)} $cur',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('رجوع')),
              TextButton(
                onPressed: p == null || p < 0 ? null : () => Navigator.pop(ctx, p),
                child: const Text('تم التسليم'),
              ),
            ],
          );
        },
      ),
    );
    if (price == null) return;
    final ok = await _run(() async {
      await _repo.completeOrder(widget.orderId, price);
    });
    if (ok) _msg('تم التسليم وحُفظت الفاتورة');
  }

  Future<void> _open(Uri uri, {Uri? fallback}) async {
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    if (fallback != null) {
      try {
        await launchUrl(fallback, mode: LaunchMode.externalApplication);
        return;
      } catch (_) {}
    }
    _msg('تعذر فتح التطبيق');
  }

  Widget _row(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Text(k),
          const Spacer(),
          Flexible(
              child: Text(v,
                  textAlign: TextAlign.end,
                  style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500))),
        ]),
      );

  Widget _section(String title, List<Widget> children) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            ...children,
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (_loadError != null) {
      return Scaffold(
          appBar: AppBar(title: const Text('تفاصيل الطلب')),
          body: Center(
              child: TextButton(onPressed: _load, child: const Text('تعذر التحميل، أعد المحاولة'))));
    }
    final o = _order;
    if (o == null) {
      return Scaffold(
          appBar: AppBar(title: const Text('تفاصيل الطلب')),
          body: const Center(child: CircularProgressIndicator()));
    }
    final d = customDetails(o);
    final status = o['status'] as String;
    final lat = o['delivery_lat'] as num?;
    final lon = o['delivery_lon'] as num?;
    final phone = o['customer_phone'] as String?;
    final items = (o['items_subtotal'] as num?) ?? 0;
    final cur = (o['currency_symbol'] ?? 'ل.ت').toString();
    final delivered = status == 'delivered';
    final canChat = const ['processing', 'ready', 'on_the_way', 'arrived'].contains(status);

    return Scaffold(
      appBar: AppBar(title: Text('طلب #${o['order_number']}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: (delivered ? Colors.green : Brand.primary).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              if (delivered)
                const Padding(
                  padding: EdgeInsetsDirectional.only(end: 8),
                  child: I3(Icons.check_circle, color: Colors.green),
                ),
              Text(statusAr[status] ?? status,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ]),
          ),
          const SizedBox(height: 12),
          if (_trip != null || _fee != null) ...[
            _section('ملخص الرحلة والرسوم', [
              if (_trip != null) ...[
                _row('بدأت الرحلة', fmtTime(_trip!['started_at'])),
                _row('انتهت الرحلة', fmtTime(_trip!['ended_at'])),
                if (_trip!['duration_s'] != null) _row('المدة', '${(_trip!['duration_s'] as num) ~/ 60} دقيقة'),
                if (_trip!['distance_m'] != null) _row('المسافة المسجلة', '${_trip!['distance_m']} متر'),
              ],
              if (_fee != null) ...[
                const Divider(),
                _row('رسوم الشركة (${_fee!['rate']}%)', '${_fee!['fee_amount']} (${_fee!['status'] ?? (_fee!['paid_at'] == null ? 'غير مسدّدة' : 'مسدّدة')})', bold: true),
              ],
            ]),
            const SizedBox(height: 12),
          ],
          _section('الزبون والتوصيل', [
            _row('الاسم', '${o['customer_name'] ?? '-'}'),
            _row('الهاتف', phone ?? '-'),
            RatingBadge(userId: o['customer_id'] as String?, label: 'تقييم الزبون'),
            _row('العنوان', '${o['delivery_address'] ?? '-'}'),
            if ((o['customer_notes'] ?? '').toString().isNotEmpty)
              _row('ملاحظات الزبون', '${o['customer_notes']}'),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: phone == null ? null : () => _open(Uri.parse('tel:$phone')),
                  icon: const I3(Icons.call),
                  label: const Text('اتصال'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: (lat == null || lon == null)
                      ? null
                      : () => _open(Uri.parse('geo:$lat,$lon?q=$lat,$lon'),
                          fallback: Uri.parse(
                              'https://www.google.com/maps/search/?api=1&query=$lat,$lon')),
                  icon: const I3(Icons.map_outlined),
                  label: const Text('فتح الموقع'),
                ),
              ),
            ]),
          ]),
          if (d != null) ...[
            const SizedBox(height: 12),
            _section('الطلب', [
              Text('${d['item_name']}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              if ((d['description'] ?? '').toString().isNotEmpty) Text('${d['description']}'),
              _row('الكمية', '${d['quantity']}'),
              if ((d['suggested_store'] ?? '').toString().isNotEmpty)
                _row('متجر مقترح', '${d['suggested_store']}'),
              ..._photosAndPlaces(d),
            ]),
          ],
          const SizedBox(height: 12),
          _section('الفاتورة', [
            _row('التوصيل الأساسي', '${fmt((o['delivery_base'] as num?) ?? 0)} $cur'),
            if (((o['distance_fee'] as num?) ?? 0) > 0)
              _row('رسوم المسافة', '${fmt(o['distance_fee'] as num)} $cur'),
            if (((o['time_fee'] as num?) ?? 0) > 0)
              _row(timeFeeLabel(o['time_fee_kind'], cur),
                  '${fmt(o['time_fee'] as num)} $cur'),
            if (((o['discount_amount'] as num?) ?? 0) > 0) ...[
              _row('الإجمالي قبل الخصم',
                  '${fmt(((o['delivery_total'] as num?) ?? 0) + (o['discount_amount'] as num))} $cur'),
              _row('خصم مستخدم جديد ${fmt((o['discount_percent'] as num?) ?? 0)}%',
                  '- ${fmt(o['discount_amount'] as num)} $cur'),
            ],
            _row('إجمالي التوصيل', '${fmt((o['delivery_total'] as num?) ?? 0)} $cur', bold: true),
            _row('سعر المشتريات', items > 0 ? '${fmt(items)} $cur' : 'يُحدد عند التسليم'),
            const Divider(),
            _row('الإجمالي', '${fmt((o['total'] as num?) ?? 0)} $cur', bold: true),
            _row('الدفع', 'نقداً عند الاستلام'),
            if (o['route_distance_m'] != null) _row('مسافة الطريق', '${o['route_distance_m']} م'),
          ]),
          const SizedBox(height: 16),
          if (canChat || delivered)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: ChatButton(
                orderId: widget.orderId,
                label: 'مراسلة الزبون',
                chatTitle: '${o['customer_name'] ?? 'الزبون'}',
              ),
            ),
          if (status == 'on_the_way' || status == 'arrived') _trackingCard(widget.orderId, status),
          if (status == 'delivered') ...[
            RatingCard(orderId: widget.orderId, title: 'قيّم الزبون'),
            const SizedBox(height: 12),
          ],
          ..._actions(o, status),
        ],
      ),
    );
  }

  Widget _trackingCard(String id, String status) {
    final st = LocationTracker.instance.state.value;
    final d = LocationTracker.instance.distanceTo(id);
    Widget body;
    Color color = Brand.primary;
    if (st.error == 'location_permission') {
      color = Colors.red;
      body = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('مشاركة الموقع متوقفة: لم يُسمح بالوصول إلى الموقع، أو أن GPS مغلق.'),
        const SizedBox(height: 6),
        OutlinedButton(
            onPressed: () => Geolocator.openAppSettings(), child: const Text('فتح إعدادات الإذن')),
      ]);
    } else if (st.position == null) {
      body = const Text('جارٍ تحديد موقعك…');
    } else if (d == null) {
      body = const Text('موقعك يُشارَك مع الزبون.');
    } else {
      body = Text('أنت على بعد ${d.round()} متراً من الزبون.');
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        I3(Icons.my_location, color: color),
        const SizedBox(width: 10),
        Expanded(child: body),
      ]),
    );
  }

  /// Photos sent by the customer, the pharmacy point, and the gas instruction.
  List<Widget> _photosAndPlaces(Map<String, dynamic> d) {
    final photos = ((d['image_urls'] as List?) ?? const []).map((e) => '$e').toList();
    final legacy = d['image_url'];
    final all = [if (legacy != null) '$legacy', ...photos];
    final lat = (d['pickup_lat'] as num?)?.toDouble();
    final lon = (d['pickup_lon'] as num?)?.toDouble();
    return [
      if (d['service'] == 'gas')
        Container(
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: Colors.orange.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
          child: const Text(
              'تنبيه: اذهب أولاً إلى منزل الزبون لأخذ الأسطوانة الفارغة، ثم بدّلها وأوصل الجديدة. سعر الأسطوانة يُقبض عند التبديل.',
              style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      if (lat != null && lon != null) ...[
        const SizedBox(height: 8),
        Text('المتجر: ${d['pickup_name'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800)),
        OutlinedButton.icon(
          onPressed: () => _open(Uri.parse('geo:$lat,$lon?q=$lat,$lon'),
              fallback: Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lon')),
          icon: const Icon(Icons.map_outlined),
          label: const Text('فتح موقع المتجر'),
        ),
      ],
      for (final u in all)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(u, height: 170, fit: BoxFit.cover)),
        ),
    ];
  }

  Future<void> _withdraw() async {
    final o = _order ?? const <String, dynamic>{};
    final cfg = await _repo.pricingSettings();
    final rate = (cfg['company_fee_rate'] as num?) ?? 15;
    final baseKind = cfg['company_fee_base']?.toString() ?? 'total';
    final base = (baseKind == 'items'
            ? o['items_subtotal']
            : baseKind == 'delivery' ? o['delivery_total'] : o['total']) as num? ?? 0;
    final fee = (base * rate / 100).toStringAsFixed(2);
    final cur = (o['currency_symbol'] ?? '').toString();
    final ctrl = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('الانسحاب من الطلب'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('تنبيه: سيُحسب عليك رسم الشركة (${rate.toStringAsFixed(0)}%) بقيمة $fee $cur بكل الأحوال، ولن يُسترد حتى لو انسحبت.'),
          const SizedBox(height: 8),
          const Text('اذكر سبب الانسحاب:'),
          const SizedBox(height: 8),
          TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(hintText: 'السبب')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('رجوع')),
          TextButton(onPressed: () => Navigator.pop(c, ctrl.text.trim()), child: const Text('انسحاب')),
        ],
      ),
    );
    if (reason == null) return;
    if (reason.length < 3) {
      _msg('اكتب سبب الانسحاب');
      return;
    }
    final ok = await _run(() => _repo.withdrawOrder(widget.orderId, reason));
    if (ok) _msg('تم الانسحاب من الطلب');
  }

  List<Widget> _actions(Map<String, dynamic> o, String status) {
    Widget big(String label, VoidCallback onTap, {Color? color, bool enabled = true}) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: FilledButton(
            style: color == null ? null : FilledButton.styleFrom(backgroundColor: color),
            onPressed: (_busy || !enabled) ? null : onTap,
            child: Text(label),
          ),
        );
    Widget outline(String label, VoidCallback onTap) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
            onPressed: _busy ? null : onTap,
            child: Text(label),
          ),
        );
    final id = widget.orderId;
    if (o['type'] == 'taxi') {
      Widget note(String text) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Text(text, textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          );
      switch (status) {
        case 'pending_driver':
          return [
            big('قبول طلب التاكسي', () => _run(() => _repo.changeStatus(id, 'processing'))),
            outline('رفض الطلب', () => _reject('rejected')),
          ];
        case 'processing':
          return [
            note('تم قبول الطلب. بانتظار الزبون ليبدأ الرحلة'),
            outline('الانسحاب من الطلب', _withdraw),
          ];
        case 'on_the_way':
          return [note('الرحلة جارية. موقعك يُشارَك مع الزبون تلقائياً')];
        case 'delivered':
          return [note('انتهت الرحلة. المبلغ المطلوب من الزبون نقداً: '
              '${fmt((o['total'] as num?) ?? 0)} ${o['currency_symbol'] ?? ''}')];
        default:
          return [];
      }
    }
    switch (status) {
      case 'pending_driver':
        return [
          big('قبول الطلب', () => _run(() => _repo.changeStatus(id, 'processing'))),
          outline('رفض الطلب', () => _reject('rejected')),
        ];
      case 'processing':
      case 'ready':
        return [
          big('استلمت الطلب وانطلقت نحو الزبون', () => _run(() async {
                if (!await LocationTracker.instance.ensurePermission()) {
                  throw Exception('location_permission');
                }
                await _repo.changeStatus(id, 'on_the_way');
              })),
          outline('إلغاء الطلب', () => _reject('cancelled')),
          if (status == 'processing') outline('الانسحاب من الطلب', _withdraw),
        ];
      case 'on_the_way':
        return [
          big('وصلت إلى موقع الزبون', () => _run(() => _repo.changeStatus(id, 'arrived')),
              color: Brand.accent),
          outline('إلغاء الطلب', () => _reject('cancelled')),
        ];
      case 'arrived':
        return [
          big('تم التسليم', () => _deliver(o), color: Colors.green),
          outline('إلغاء الطلب', () => _reject('cancelled')),
        ];
      case 'awaiting_review':
        return [outline('رفض الطلب', () => _reject('rejected'))];
      case 'awaiting_customer_approval':
        return [outline('إلغاء الطلب', () => _reject('cancelled'))];
      default:
        return [];
    }
  }
}
