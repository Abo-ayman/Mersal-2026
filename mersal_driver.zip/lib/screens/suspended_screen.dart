import 'package:flutter/material.dart';

import '../core/logo.dart';

/// Shown instead of the app while the admin has suspended this account. The back button does nothing.
class SuspendedScreen extends StatelessWidget {
  final String? reason;
  const SuspendedScreen({super.key, this.reason});

  @override
  Widget build(BuildContext context) {
    final text = (reason ?? '').trim();
    return PopScope(
      canPop: false,
      child: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const MersalLogo(markSize: 96),
              const SizedBox(height: 28),
              const Text('حسابك موقوف مؤقتاً',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              if (text.isNotEmpty)
                Text('السبب: $text', textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 16),
              const Text('للاستفسار تواصل مع إدارة مرسال.', textAlign: TextAlign.center),
            ]),
          ),
        ),
      ),
    );
  }
}
