import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/staff_repository.dart';

class CompanyFeesScreen extends StatefulWidget {
  const CompanyFeesScreen({super.key});

  @override
  State<CompanyFeesScreen> createState() => _CompanyFeesScreenState();
}

class _CompanyFeesScreenState extends State<CompanyFeesScreen> {
  final _repo = StaffRepository();
  late Future<_Data> _future = _load();

  Future<_Data> _load() async {
    final fees = await _repo.myFees();
    final summary = await _repo.feesSummary();
    final admin = await _repo.isAdmin();
    return _Data(fees, summary, admin);
  }

  void _reload() => setState(() => _future = _load());

  Future<void> _settle() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تسجيل السداد'),
        content: const Text('سيتم تسجيل كل الرسوم غير المسددة كمسددة. هل سددتها للشركة فعلاً؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم، تم السداد')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final n = await _repo.settleMyFees();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('سُجّل سداد $n رسوم')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رسوم الشركة')),
      body: FutureBuilder<_Data>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: TextButton(onPressed: _reload, child: const Text('تعذر التحميل، أعد المحاولة')));
          }
          final d = snap.data!;
          final count = (d.summary['count'] as num).toInt();
          final limit = (d.summary['limit'] as num).toInt();
          final totalText = d.summary['totalText'] as String;
          final blocked = count >= limit;
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: (blocked ? Colors.red : Brand.primary).withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: blocked ? Colors.red : Brand.line),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('المستحق للشركة'),
                    Text(totalText,
                        style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            color: blocked ? Colors.red : Brand.ink)),
                    const SizedBox(height: 8),
                    Text('رسوم غير مسددة: $count من $limit'),
                    const SizedBox(height: 6),
                    LinearProgressIndicator(
                      value: limit == 0 ? 0 : (count / limit).clamp(0, 1).toDouble(),
                      color: blocked ? Colors.red : Brand.accent,
                      backgroundColor: Brand.line,
                    ),
                    if (blocked) ...[
                      const SizedBox(height: 8),
                      const Text('وصلت للحد الأقصى. سدّد الرسوم لتتمكن من قبول طلبات جديدة.',
                          style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
                    ],
                  ]),
                ),
                if (d.admin && count > 0) ...[
                  const SizedBox(height: 12),
                  FilledButton(onPressed: _settle, child: const Text('تسجيل سداد الرسوم')),
                ],
                const SizedBox(height: 16),
                if (d.fees.isEmpty)
                  const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('لا توجد رسوم بعد')))
                else
                  for (final f in d.fees)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Card(
                        child: ListTile(
                          title: Text('- ${fmt(f['fee_amount'] as num)} ${f['currency_symbol'] ?? 'ل.ت'}',
                              style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  color: f['status'] == 'paid' ? Colors.black45 : Colors.red)),
                          subtitle: Text(
                              'طلب #${(f['orders'] is Map) ? f['orders']['order_number'] : ''} · ${fmt(f['rate'] as num)}% من ${fmt(f['base_amount'] as num)} ${f['currency_symbol'] ?? 'ل.ت'}'),
                          trailing: Chip(
                              label: Text(f['status'] == 'paid' ? 'مسددة' : 'غير مسددة')),
                        ),
                      ),
                    ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _Data {
  final List<Map<String, dynamic>> fees;
  final Map<String, dynamic> summary;
  final bool admin;
  _Data(this.fees, this.summary, this.admin);
}
