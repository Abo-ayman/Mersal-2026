import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../core/logo.dart';
import '../core/location_tracker.dart';
import '../core/push.dart';
import '../core/pulse.dart';
import '../core/theme.dart';
import '../data/staff_repository.dart';
import 'company_fees_screen.dart';
import 'login_screen.dart';
import 'order_detail_screen.dart';

const _tabs = <(String, List<String>)>[
  ('جديدة', ['awaiting_review', 'pending_driver']),
  ('بانتظار الزبون', ['awaiting_customer_approval']),
  ('قيد التنفيذ', ['processing', 'ready', 'on_the_way']),
  ('السجل', ['delivered', 'rejected', 'cancelled']),
];

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  final _repo = StaffRepository();
  Timer? _timer;
  List<Map<String, dynamic>> _orders = [];
  Set<String> _unseen = {};
  Set<String> _chatUnread = {};
  Map<String, dynamic> _fees = {'count': 0, 'totalText': '0', 'limit': 10};
  bool _loaded = false;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(
        const Duration(seconds: AppConfig.refreshSeconds), (_) => _load());
    Push.pushTick.addListener(_load);
  }

  @override
  void dispose() {
    _timer?.cancel();
    Push.pushTick.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final all = _tabs.expand((t) => t.$2).toList();
      final orders = await _repo.orders(all);
      final uid = Supabase.instance.client.auth.currentUser?.id;
      LocationTracker.instance.syncOrders([
        for (final o in orders)
          if (o['driver_id'] == uid && (o['status'] == 'on_the_way' || o['status'] == 'arrived')) o
      ]);
      final unseen = await _repo.unseenIds(orders);
      final chatUnread = await _repo.unreadChatOrderIds();
      final fees = await _repo.feesSummary();
      if (!mounted) return;
      setState(() {
        _orders = orders;
        _unseen = unseen;
        _chatUnread = chatUnread;
        _fees = fees;
        _loaded = true;
        _error = false;
      });
    } catch (_) {
      if (mounted) setState(() => _error = !_loaded);
    }
  }

  Future<void> _logout() async {
    await Push.unregister();
    await _repo.signOut();
    if (!mounted) return;
    Navigator.of(context)
        .pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  List<Map<String, dynamic>> _forTab(List<String> statuses) =>
      _orders.where((o) => statuses.contains(o['status'])).toList();

  bool _tabHasUnseen(List<String> statuses) =>
      _forTab(statuses).any((o) => _unseen.contains(o['id']));

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: _tabs.length,
      child: Scaffold(
        appBar: AppBar(
          title: const MersalLogo(markSize: 30, horizontal: true),
          actions: [
            IconButton(onPressed: _logout, icon: const Icon(Icons.logout), tooltip: 'خروج'),
          ],
          bottom: TabBar(
            isScrollable: true,
            labelColor: Brand.primary,
            indicatorColor: Brand.primary,
            tabs: [
              for (final t in _tabs)
                Tab(
                  child: Badge(
                    isLabelVisible: _tabHasUnseen(t.$2),
                    smallSize: 10,
                    backgroundColor: Colors.red,
                    alignment: AlignmentDirectional.topEnd,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Text(t.$1),
                    ),
                  ),
                ),
            ],
          ),
        ),
        body: !_loaded
            ? Center(
                child: _error
                    ? TextButton(onPressed: _load, child: const Text('تعذر التحميل، أعد المحاولة'))
                    : const CircularProgressIndicator())
            : Column(children: [
                _feesBanner(),
                Expanded(
                  child: TabBarView(
                    children: [for (final t in _tabs) _buildList(_forTab(t.$2))],
                  ),
                ),
              ]),
      ),
    );
  }

  Widget _feesBanner() {
    final count = (_fees['count'] as num).toInt();
    final limit = (_fees['limit'] as num).toInt();
    final totalText = _fees['totalText'] as String;
    final blocked = count >= limit;
    final color = blocked ? Colors.red : (count > 0 ? Colors.orange.shade800 : Brand.primary);
    return InkWell(
      onTap: () async {
        await Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const CompanyFeesScreen()));
        _load();
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: 0.4)),
        ),
        child: Row(children: [
          Icon(Icons.account_balance_wallet_outlined, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              count == 0
                  ? 'رسوم الشركة: لا توجد رسوم مستحقة'
                  : 'رسوم الشركة: - $totalText ($count من $limit طلب غير مسدد)',
              style: TextStyle(fontWeight: FontWeight.w700, color: color),
            ),
          ),
          Icon(Icons.chevron_left, color: color),
        ]),
      ),
    );
  }

  Widget _buildList(List<Map<String, dynamic>> orders) {
    return RefreshIndicator(
      onRefresh: _load,
      child: orders.isEmpty
          ? ListView(children: const [
              SizedBox(height: 120),
              Center(child: Text('لا توجد طلبات')),
            ])
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final o = orders[i];
                final d = customDetails(o);
                final isCustom = o['type'] == 'custom';
                final fresh = _unseen.contains(o['id']);
                return PulseGlow(
                  active: fresh,
                  child: Card(
                    child: ListTile(
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      title: Row(children: [
                        if (fresh)
                          Container(
                            width: 10,
                            height: 10,
                            margin: const EdgeInsetsDirectional.only(end: 8),
                            decoration: const BoxDecoration(
                                color: Colors.red, shape: BoxShape.circle),
                          ),
                        Expanded(
                          child: Text(
                            isCustom
                                ? (d?['item_name'] ?? 'طلب خاص')
                                : 'طلب #${o['order_number']}',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        if (_chatUnread.contains(o['id']))
                          const Icon(Icons.mark_chat_unread, color: Colors.red, size: 22),
                      ]),
                      subtitle: Text(
                        '#${o['order_number']} · ${o['customer_name'] ?? 'زبون'}\n${statusAr[o['status']] ?? o['status']}',
                      ),
                      isThreeLine: true,
                      trailing: isCustom ? const Chip(label: Text('اطلب أي شيء')) : null,
                      onTap: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => OrderDetailScreen(orderId: o['id'])));
                        _load();
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}
