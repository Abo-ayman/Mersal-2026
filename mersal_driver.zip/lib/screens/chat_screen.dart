import 'package:flutter/material.dart';
import '../core/icon3d.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';
import '../data/staff_repository.dart';

/// Order chat between the customer and the driver (open only while the order is active).
class ChatScreen extends StatefulWidget {
  final String orderId;
  final String title;
  const ChatScreen({super.key, required this.orderId, required this.title});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _db = Supabase.instance.client;
  final _ctrl = TextEditingController();
  bool _sending = false;
  DateTime? _markedUpTo; // newest incoming message already marked as read

  late final Stream<List<Map<String, dynamic>>> _stream = _db
      .from('order_messages')
      .stream(primaryKey: ['id'])
      .eq('order_id', widget.orderId)
      .order('created_at');

  /// Marks the incoming messages as read on the server (once per new incoming message).
  void _markReadIfNeeded(List<Map<String, dynamic>> msgs) {
    final me = _db.auth.currentUser?.id;
    DateTime? newest;
    for (final m in msgs) {
      if (m['sender_id'] == me) continue;
      final at = DateTime.tryParse('${m['created_at']}');
      if (at != null && (newest == null || at.isAfter(newest))) newest = at;
    }
    if (newest == null) return;
    if (_markedUpTo != null && !newest.isAfter(_markedUpTo!)) return;
    _markedUpTo = newest;
    _db.rpc('mark_chat_read', params: {'p_order': widget.orderId}).then((_) {}, onError: (_) {});
  }

  @override
  void initState() {
    super.initState();
    _db.rpc('mark_chat_read', params: {'p_order': widget.orderId}).then((_) {}, onError: (_) {});
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      await _db.rpc('send_order_message',
          params: {'p_order': widget.orderId, 'p_body': text});
      _ctrl.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = _db.auth.currentUser?.id;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _stream,
              builder: (context, snap) {
                final msgs = (snap.data ?? []).reversed.toList();
                WidgetsBinding.instance.addPostFrameCallback((_) => _markReadIfNeeded(msgs));
                if (snap.connectionState == ConnectionState.waiting && msgs.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (msgs.isEmpty) {
                  return const Center(child: Text('ابدأ المحادثة'));
                }
                return ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(12),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final m = msgs[i];
                    final mine = m['sender_id'] == me;
                    return Align(
                      alignment: mine ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                        decoration: BoxDecoration(
                          color: mine ? Brand.primary : Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: mine ? null : Border.all(color: Brand.line),
                        ),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [if (m['image_url'] != null) Padding(padding: const EdgeInsets.only(bottom: 6), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network('${m['image_url']}', width: 210, fit: BoxFit.cover))), if (m['body'] != null) Text('${m['body']}', style: TextStyle(color: mine ? Colors.white : Brand.ink)),]),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    minLines: 1,
                    maxLines: 4,
                    decoration: const InputDecoration(hintText: 'اكتب رسالة...'),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _sending ? null : _send,
                  icon: const I3(Icons.send),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
