import 'package:supabase_flutter/supabase_flutter.dart';

class StaffRepository {
  SupabaseClient get _db => Supabase.instance.client;

  Future<void> signIn(String email, String password) async {
    await _db.auth.signInWithPassword(email: email.trim(), password: password);
  }

  Future<void> signOut() => _db.auth.signOut();

  bool get signedIn => _db.auth.currentSession != null;

  /// Role check is also enforced on the server for every action.
  Future<bool> isStaff() async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) return false;
    final rows = await _db
        .from('user_roles')
        .select('role')
        .eq('user_id', uid)
        .inFilter('role', ['driver', 'admin']);
    return (rows as List).isNotEmpty;
  }

  Future<List<Map<String, dynamic>>> orders(List<String> statuses) async {
    final rows = await _db
        .from('orders')
        .select('*, custom_order_details(*)')
        .inFilter('status', statuses)
        .order('created_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }


  /// Orders that changed (by someone else) since this user last opened them.
  Future<Set<String>> unseenIds(List<Map<String, dynamic>> orders) async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) return {};
    final rows = await _db.from('order_seen').select('order_id, seen_at').eq('user_id', uid);
    final seen = <String, DateTime>{};
    for (final r in rows as List) {
      seen[r['order_id'] as String] = DateTime.parse(r['seen_at'] as String);
    }
    final out = <String>{};
    for (final o in orders) {
      if (o['last_event_by'] == uid) continue; // my own action is never "new" to me
      final at = DateTime.tryParse('${o['last_event_at']}');
      final s = seen[o['id']];
      if (s == null || (at != null && at.isAfter(s))) out.add(o['id'] as String);
    }
    return out;
  }


  /// Orders where the other party wrote a chat message I have not read yet.
  Future<Set<String>> unreadChatOrderIds() async {
    try {
      final res = await _db.rpc('my_unread_chat_order_ids');
      return (res as List).map((e) => e.toString()).toSet();
    } catch (_) {
      return {};
    }
  }

  Future<void> markSeen(String orderId) async {
    try {
      await _db.rpc('mark_order_seen', params: {'p_order': orderId});
    } catch (_) {}
  }

  Future<Map<String, dynamic>> order(String id) async {
    return await _db
        .from('orders')
        .select('*, custom_order_details(*)')
        .eq('id', id)
        .single();
  }

  Future<Map<String, dynamic>> pricingSettings() async {
    return await _db.from('pricing_settings').select().eq('id', 1).single();
  }

  /// Server-side fee calculation (same function used when the quote is saved).
  Future<Map<String, dynamic>> feePreview(int distanceM) async {
    final res = await _db.rpc('calc_delivery_fee', params: {
      'p_distance_m': distanceM,
      'p_at': DateTime.now().toUtc().toIso8601String(),
    });
    final list = res as List;
    return Map<String, dynamic>.from(list.first as Map);
  }

  Future<Map<String, dynamic>> quote({
    required String orderId,
    required num itemPrice,
    required int routeDistanceM,
    String? note,
  }) async {
    final res = await _db.rpc('quote_custom_order', params: {
      'p_order': orderId,
      'p_item_price': itemPrice,
      'p_store_id': null,
      'p_route_distance_m': routeDistanceM,
      'p_note': note,
    });
    return Map<String, dynamic>.from(res as Map);
  }

  /// Delivery confirmation: the driver enters the real price of the goods.
  Future<Map<String, dynamic>> completeOrder(String orderId, num itemsPrice) async {
    final res = await _db.rpc('staff_complete_order',
        params: {'p_order': orderId, 'p_items_price': itemsPrice});
    return Map<String, dynamic>.from(res as Map);
  }

  // ---- company fees ----
  Future<List<Map<String, dynamic>>> myFees() async {
    final uid = _db.auth.currentUser!.id;
    final rows = await _db
        .from('company_fees')
        .select('*, orders(order_number)')
        .eq('driver_id', uid)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  /// {count, total, limit} of unpaid fees for the signed-in driver.
  Future<Map<String, num>> feesSummary() async {
    final uid = _db.auth.currentUser!.id;
    final rows = await _db
        .from('company_fees')
        .select('fee_amount')
        .eq('driver_id', uid)
        .eq('status', 'unpaid');
    final list = rows as List;
    num total = 0;
    for (final r in list) {
      total += (r['fee_amount'] as num);
    }
    final s = await pricingSettings();
    return {'count': list.length, 'total': total, 'limit': (s['max_unpaid_fees'] as num)};
  }

  Future<bool> isAdmin() async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) return false;
    final rows = await _db.from('user_roles').select('role').eq('user_id', uid).eq('role', 'admin');
    return (rows as List).isNotEmpty;
  }

  Future<int> settleMyFees({String? note}) async {
    final uid = _db.auth.currentUser!.id;
    final n = await _db.rpc('settle_company_fees', params: {'p_driver': uid, 'p_note': note});
    return (n as num).toInt();
  }

  Future<void> changeStatus(String orderId, String to, {String? reason}) async {
    await _db.rpc('staff_change_status',
        params: {'p_order': orderId, 'p_to': to, 'p_reason': reason});
  }
}

const statusAr = {
  'awaiting_review': 'بانتظار مراجعتك',
  'awaiting_customer_approval': 'بانتظار موافقة الزبون',
  'pending_driver': 'بانتظار قبولك',
  'processing': 'مقبول، في طريقك للمتجر',
  'ready': 'جاهز للتوصيل',
  'on_the_way': 'في الطريق للزبون',
  'arrived': 'وصلت إلى الزبون',
  'delivered': 'تم التسليم',
  'rejected': 'مرفوض',
  'cancelled': 'ملغى',
};

String friendlyError(Object e) {
  final m = e.toString();
  if (m.contains('unpaid_fees_limit')) return 'unpaid_fees_limit';
  if (m.contains('chat_closed')) return 'المحادثة مغلقة لهذا الطلب';
  if (m.contains('not_allowed')) return 'ليست لديك صلاحية لهذا الإجراء';
  if (m.contains('transition_not_allowed')) return 'لا يمكن الانتقال لهذه الحالة الآن';
  if (m.contains('wrong_status')) return 'تغيّرت حالة الطلب، حدّث الصفحة';
  if (m.contains('invalid_price')) return 'السعر غير صحيح';
  if (m.contains('route_distance_required')) return 'مسافة الطريق مطلوبة';
  if (m.contains('Invalid login')) return 'البريد أو كلمة المرور غير صحيحة';
  return 'حدث خطأ، حاول مرة أخرى';
}

Map<String, dynamic>? customDetails(Map<String, dynamic> o) {
  final d = o['custom_order_details'];
  if (d is List) return d.isEmpty ? null : Map<String, dynamic>.from(d.first);
  if (d is Map) return Map<String, dynamic>.from(d);
  return null;
}

String fmt(num n) => n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(2);
