import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config.dart';

/// Road-distance provider. The rest of the app only depends on this interface,
/// so the provider (OSRM now) can be swapped later.
abstract class RoutingService {
  /// Driving distance in meters, or null if no reliable route could be found.
  Future<int?> drivingDistanceMeters({
    required double fromLat,
    required double fromLon,
    required double toLat,
    required double toLon,
  });
}

class OsrmRoutingService implements RoutingService {
  @override
  Future<int?> drivingDistanceMeters({
    required double fromLat,
    required double fromLon,
    required double toLat,
    required double toLon,
  }) async {
    final url = Uri.parse(
        '${AppConfig.osrmBase}/route/v1/driving/$fromLon,$fromLat;$toLon,$toLat?overview=false');
    try {
      final res = await http.get(url).timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) return null;
      final json = jsonDecode(res.body) as Map<String, dynamic>;
      if (json['code'] != 'Ok') return null;
      final routes = json['routes'] as List;
      if (routes.isEmpty) return null;
      return ((routes.first['distance']) as num).round();
    } catch (_) {
      return null;
    }
  }
}
