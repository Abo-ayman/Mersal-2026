import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../firebase_config.dart';

/// Lets us show a banner when a push arrives while the app is open.
final messengerKey = GlobalKey<ScaffoldMessengerState>();

class Push {
  /// Bumped whenever a push arrives while the app is open, so screens can refresh.
  static final ValueNotifier<int> pushTick = ValueNotifier<int>(0);
  static bool _ready = false;
  static bool _listening = false;

  /// Safe to call always: does nothing until Firebase values are filled in.
  static Future<void> init() async {
    if (!FirebaseConfig.enabled) return;
    try {
      await Firebase.initializeApp(options: FirebaseConfig.options)
          .timeout(const Duration(seconds: 15));
      _ready = true;
      FirebaseMessaging.onMessage.listen((m) {
        pushTick.value++;
        final n = m.notification;
        if (n == null) return;
        messengerKey.currentState?.showSnackBar(SnackBar(
          duration: const Duration(seconds: 6),
          content: Text([n.title, n.body].whereType<String>().join(': ')),
        ));
      });
    } catch (_) {}
  }

  /// Call after the user is signed in: asks permission and saves the device token on the server.
  static Future<void> register() async {
    if (!_ready) return;
    try {
      final fm = FirebaseMessaging.instance;
      await fm.requestPermission();
      final token = await fm.getToken();
      if (token != null) await _save(token);
      if (!_listening) {
        _listening = true;
        fm.onTokenRefresh.listen(_save);
      }
    } catch (_) {}
  }

  static Future<void> unregister() async {
    if (!_ready) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) {
        await Supabase.instance.client
            .rpc('unregister_device_token', params: {'p_token': token});
      }
    } catch (_) {}
  }

  static Future<void> _save(String token) async {
    if (Supabase.instance.client.auth.currentUser == null) return;
    try {
      await Supabase.instance.client
          .rpc('register_device_token', params: {'p_token': token});
    } catch (_) {}
  }
}
