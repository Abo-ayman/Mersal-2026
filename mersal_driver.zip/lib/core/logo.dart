import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'theme.dart';

/// The MERSAL mark: the new 3D logo badge.
class MersalMark extends StatelessWidget {
  final double size;
  const MersalMark({super.key, this.size = 96});

  @override
  Widget build(BuildContext context) =>
      Image.asset('assets/icons/app_logo.png', width: size, height: size, fit: BoxFit.contain);
}

/// Mark + the word "مرسال" (Cairo).
class MersalLogo extends StatelessWidget {
  final double markSize;
  final bool horizontal;
  const MersalLogo({super.key, this.markSize = 96, this.horizontal = false});

  @override
  Widget build(BuildContext context) {
    final text = Text(
      'مرسال',
      style: GoogleFonts.cairo(
        fontSize: markSize * (horizontal ? 0.62 : 0.5),
        fontWeight: FontWeight.w900,
        color: Brand.primary,
        height: 1.1,
      ),
    );
    final mark = MersalMark(size: markSize);
    return horizontal
        ? Row(mainAxisSize: MainAxisSize.min, children: [mark, const SizedBox(width: 8), text])
        : Column(mainAxisSize: MainAxisSize.min, children: [mark, const SizedBox(height: 8), text]);
  }
}
