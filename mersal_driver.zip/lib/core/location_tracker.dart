import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class TrackerState {
  final Position? position;
  final DateTime? lastReportAt;
  final bool active;
  final String? error;
  const TrackerState({this.position, this.lastReportAt, this.active = false, this.error});
}

/// Shares the driver's position with the server while at least one of his orders is
/// "on the way" or "arrived". Uses an Android foreground service (persistent notification)
/// so it keeps working with the screen off. Stops by itself when no active order is left.
class LocationTracker {
  LocationTracker._();
  static final LocationTracker instance = LocationTracker._();

  final ValueNotifier<TrackerState> state = ValueNotifier(const TrackerState());
  final Map<String, ({double lat, double lon})> _targets = {};
  StreamSubscription<Position>? _sub;
  bool _reporting = false;

  /// Asks for the location permission. Returns false if it cannot be used.
  Future<bool> ensurePermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) return false;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    return p == LocationPermission.whileInUse || p == LocationPermission.always;
  }

  /// [orders] = the driver's orders that are currently on the way / arrived.
  Future<void> syncOrders(List<Map<String, dynamic>> orders) async {
    _targets
      ..clear()
      ..addEntries([
        for (final o in orders)
          if (o['delivery_lat'] != null && o['delivery_lon'] != null)
            MapEntry(o['id'] as String, (
              lat: (o['delivery_lat'] as num).toDouble(),
              lon: (o['delivery_lon'] as num).toDouble(),
            )),
      ]);
    // orders without coordinates still need reporting
    for (final o in orders) {
      _targets.putIfAbsent(o['id'] as String, () => (lat: 0.0, lon: 0.0));
    }
    if (_targets.isEmpty) {
      await stop();
    } else if (_sub == null) {
      await _start();
    }
  }

  /// Distance in meters from the last known position to the customer of [orderId].
  double? distanceTo(String orderId) {
    final p = state.value.position;
    final t = _targets[orderId];
    if (p == null || t == null || (t.lat == 0 && t.lon == 0)) return null;
    return Geolocator.distanceBetween(p.latitude, p.longitude, t.lat, t.lon);
  }

  Future<void> _start() async {
    if (!await ensurePermission()) {
      state.value = const TrackerState(error: 'location_permission');
      return;
    }
    final settings = AndroidSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 0,
      intervalDuration: const Duration(seconds: 5),
      foregroundNotificationConfig: const ForegroundNotificationConfig(
        notificationTitle: 'مرسال سائق',
        notificationText: 'يتم مشاركة موقعك مع الزبون أثناء التوصيل',
        enableWakeLock: true,
        setOngoing: true,
      ),
    );
    state.value = const TrackerState(active: true);
    _sub = Geolocator.getPositionStream(locationSettings: settings).listen(
      _onPosition,
      onError: (_) => state.value = TrackerState(
          position: state.value.position, active: true, error: 'gps_error'),
    );
  }

  Future<void> _onPosition(Position p) async {
    state.value = TrackerState(
        position: p, lastReportAt: state.value.lastReportAt, active: true);
    if (_reporting) return;
    _reporting = true;
    String? err;
    try {
      final db = Supabase.instance.client;
      for (final id in _targets.keys.toList()) {
        await db.rpc('driver_report_location', params: {
          'p_order': id,
          'p_lat': p.latitude,
          'p_lon': p.longitude,
          'p_accuracy': p.accuracy,
        });
      }
    } catch (e) {
      err = 'report_failed';
    } finally {
      _reporting = false;
    }
    state.value = TrackerState(
      position: p,
      lastReportAt: err == null ? DateTime.now() : state.value.lastReportAt,
      active: true,
      error: err,
    );
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    _targets.clear();
    state.value = const TrackerState();
  }
}
