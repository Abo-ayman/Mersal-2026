/// Public values only. Never put a service_role key here.
class AppConfig {
  static const supabaseUrl = 'https://cdovwraosimjhktnkenc.supabase.co';
  static const supabaseKey = 'sb_publishable_BToPU4Q76axfAjnrBQnnlw_zuN6VqcB';

  /// Public OSRM demo server (free, best effort, not for heavy production use).
  static const osrmBase = 'https://router.project-osrm.org';

  /// How often the order lists refresh while the app is open (no push yet).
  static const refreshSeconds = 15;
}
